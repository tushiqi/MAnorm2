# For loading operations and startup message.
#
# Last update: 2022-08-24


# Display startup message
.onAttach <- function(libname, pkgname) {
    packageStartupMessage("MAnorm2 1.2.1 2022-08-24")
}


