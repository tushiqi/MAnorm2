# For loading operations and startup message.
#
# Last update: 2022-10-28


# Display startup message
.onAttach <- function(libname, pkgname) {
    packageStartupMessage("MAnorm2 1.2.2 2022-10-28")
}


