# For loading operations and startup message.
#
# Last update: 2021-09-10


# Display startup message
.onAttach <- function(libname, pkgname) {
    packageStartupMessage("MAnorm2 1.2.0 2021-09-10")
}


