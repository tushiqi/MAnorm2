# For loading operations and startup message.
#
# Last update: 2019-12-01


# Display startup message
.onAttach <- function(libname, pkgname) {
    packageStartupMessage("MAnorm2 1.0.0 2019-12-01")
}


